package productdemo;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ProductDemo extends Application {
    private Stage stage;
    
    TableView<Product> productTable;
    public Button  addProduct;
    private TextField addPPrice, addPAmount, addPName;
    TableView<Product> productAdminTable;
    TableColumn<Product, Integer> productAmountColumn;
    TableColumn<Product, String> productNameColumn;
    TableColumn<Product, Double> productPriceColumn;
    static ProductController productController;
    static Product model;
    
    VBox vbox;
    HBox hbox;
    Scene scene;
    HBox adminHbox;
    private int adminPassword;
    
    private int credit_Card;
    Stage window;
    TextField password;
    @Override
    public void start(Stage primaryStage) {
        stage = primaryStage;
       
        userPage();
    }

    public static void main(String[] args) {
        //model = new Product();
        model = Product.getProductInstance();
        productController = new ProductController(model);
        productController.fillData();
        launch(args);
        
    }
    public void userPage() {
        productNameColumn = new TableColumn<>("Name");
        productNameColumn.setMinWidth(300);
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("productName"));
        productPriceColumn = new TableColumn<>("Price");
        productPriceColumn.setMinWidth(300);
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<>("productPrice"));
        productAmountColumn = new TableColumn<>("Amount");
        productAmountColumn.setMinWidth(200);
        productAmountColumn.setCellValueFactory(new PropertyValueFactory<>("productAmount"));
        productTable = new TableView<>();
        productTable.setItems(productController.updateProductList());
        productTable.getColumns().addAll(productNameColumn, productPriceColumn, productAmountColumn);
        // user level buttons and textfields
        Button admin = new Button("Admin");
        password = new TextField();
        password.setPromptText("admin password");
        admin.setOnAction(e -> adminPage());

        hbox = new HBox();
        hbox.setPadding(new Insets(10, 10, 10, 10));
        hbox.setSpacing(8);
        hbox.getChildren().addAll(password, admin);
        vbox = new VBox();
        vbox.getChildren().addAll(productTable, hbox);
        
        scene = new Scene(vbox);
        
        stage.setTitle("Products");
        stage.setScene(scene);
        stage.show();
    }
    public void AddProductWindow() {
        window = new Stage();
        Label addProductDesc;
        
        addProductDesc = new Label("Add Product");
        addProduct = new Button("add product");
        window.initModality(Modality.APPLICATION_MODAL);
        window.setMinWidth(500);
        Button addProduct = new Button("Add");
        addProduct.setOnAction(e -> addProduct());
        Button cancel = new Button("cancel");
        cancel.setOnAction(e -> window.close());
        addPName = new TextField();
        addPName.setPromptText("Add Name");
        addPPrice = new TextField();
        addPPrice.setPromptText("Add Price");
        addPAmount = new TextField();
        addPAmount.setPromptText("Add Amount");
        addPName.setText("Add Name");
        VBox vBox = new VBox();
        HBox hBox = new HBox();
        hBox.setSpacing(10);
        hBox.getChildren().addAll(addProduct, cancel);
        vBox.setPadding(new Insets(15, 15, 15, 15));
        vBox.getChildren().addAll(addProductDesc, addPName, addPPrice, addPAmount, hBox);
        vBox.setSpacing(10);
        Scene scene = new Scene(vBox);
        window.setScene(scene);
        window.showAndWait();
    }
    public void adminPage() {
        String passwordValue = "1234";
        String adminPassword = "";
        if(!(password.getText().equals(""))) {
            adminPassword = password.getText().toString();
        }
        
        if(password.getText().equals("")) {
             password.setPromptText("enter password first");
            System.out.println("Enter your password first");
        }
        
        else if(!adminPassword.equals(passwordValue)) {
            password.setText("");
            password.setPromptText("not Valid password");
            System.out.println("The Password is not valid please try again");
        }
        else if(adminPassword.equals(passwordValue)) {
        Button addProduct = new Button("Add Product");
        Button user = new Button("user mode");
        Button deleteProduct = new Button("Delete Product");
        
        productAdminTable = new TableView<>();
        TableColumn<Product, String> productAdminNameColumn = new TableColumn<>("Name");
        productAdminNameColumn.setMinWidth(200);
        productAdminNameColumn.setCellValueFactory(new PropertyValueFactory<>("productName"));
        
        TableColumn<Product, String> productAdminPriceColumn = new TableColumn<>("Price");
        productAdminPriceColumn.setMinWidth(200);
        productAdminPriceColumn.setCellValueFactory(new PropertyValueFactory<>("productPrice"));
        
        TableColumn<Product, String> productAdminAmountColumn = new TableColumn<>("Amount");
        productAdminAmountColumn.setMinWidth(200);
        productAdminAmountColumn.setCellValueFactory(new PropertyValueFactory<>("productAmount"));
        
        TableColumn<Product, String> productAdminShippedColumn = new TableColumn<>("sales figure");
        productAdminShippedColumn.setMinWidth(200);
        productAdminShippedColumn.setCellValueFactory(new PropertyValueFactory<>("productShipped"));
        
        productAdminTable.setItems(productController.getProduct());
        productAdminTable.getColumns().addAll(productAdminNameColumn, productAdminPriceColumn, productAdminAmountColumn, productAdminShippedColumn);
        
        
        adminHbox = new HBox();
        adminHbox.setPadding(new Insets(10, 10, 10, 10));
        adminHbox.setSpacing(25);
        productTable.getColumns().removeAll(productNameColumn, productPriceColumn);
        
        productNameColumn.setMinWidth(200);
        productPriceColumn.setMinWidth(200);
        adminHbox.getChildren().addAll(user, deleteProduct,addProduct);
        
        productTable.getColumns().addAll(productNameColumn, productPriceColumn, productAdminShippedColumn);
        vbox.getChildren().removeAll(productTable, hbox);
        vbox.getChildren().addAll(productAdminTable, adminHbox);
        // add product 
        addProduct.setOnAction(e -> AddProductWindow());
        
        // switch to user page
        user.setOnAction(e -> userPage());
        
        // delete product
        deleteProduct.setOnAction(e -> deleteProductWindow());

        }
    }
    public void addProduct() {
        String getProductName = addPName.getText().toString();
        double getProductPrice = 0;
        int getProductAmount = 0;
        try {
            getProductPrice = Double.parseDouble(addPPrice.getText().toString());
            getProductAmount = Integer.parseInt(addPAmount.getText().toString());
        }catch(Exception e) {
            //e.printStackTrace();
            System.out.println(e);
        }
        
        
        if(getProductName.equals("")) {
            addPName.setPromptText("fill product name");
        }
        if(addPPrice.getText().toString().equals("")) {
            addPPrice.setPromptText("fill product price");
        }
        if(addPAmount.getText().toString().equals("")) {
            addPAmount.setPromptText("fill product amount");
        }
        if(!getProductName.equals("") && !addPPrice.getText().toString().equals("") && !addPAmount.getText().toString().equals("")) {
            productController.addProduct(new Product(getProductName, getProductPrice, getProductAmount, 0));
            window.close();
        }
        
    }
    public void deleteProductWindow() {
        ObservableList<Product> selectedProduct, selectedItem;
        Label confirmDelete;
        try {
        selectedProduct = productAdminTable.getSelectionModel().getSelectedItems();
         int deleteRow = productAdminTable.getSelectionModel().getSelectedIndex();
        
            String productName = selectedProduct.get(0).getProductName();
            
           confirmDelete = new Label("Are you sure to delete product '" + productName + "' ?");
           window = new Stage();
           window.setTitle("Delete Product");
           window.initModality(Modality.APPLICATION_MODAL);
           window.setMinWidth(500);
           Button deleteProduct = new Button("Delete");
           deleteProduct.setOnAction(e -> deleteProduct());
           Button cancel = new Button("cancel");
           cancel.setOnAction(e -> window.close());

           VBox vBox = new VBox();
           vBox.setPadding(new Insets(20, 20, 20, 20));
           HBox hBox = new HBox();
           hBox.setPadding(new Insets(20, 20, 20, 20));
           hBox.setSpacing(8);
           hBox.getChildren().addAll(deleteProduct, cancel);

           vBox.getChildren().addAll(confirmDelete, hBox);
           Scene scene = new Scene(vBox);
           window.setScene(scene);
           window.showAndWait();
        }catch(Exception e) {
            System.out.println("Please selecte the product to delete");
        }
       
    
    }
    public void deleteProduct() {
        ObservableList<Product> selectedProduct, selectedItem;
        try {
        selectedProduct = productAdminTable.getSelectionModel().getSelectedItems();
        int deleteRow = productAdminTable.getSelectionModel().getSelectedIndex();
        
            String productName = selectedProduct.get(0).getProductName();
            double productPrice = selectedProduct.get(0).getProductPrice();
            int productAmount = selectedProduct.get(0).getProductAmount();
            int productShipped = selectedProduct.get(0).getProductShipped();

            productController.deleteProduct(deleteRow);
            window.close();
        }catch(Exception e) {
            System.out.println("Please selecte the product to delete");
        }
    }
   
}
