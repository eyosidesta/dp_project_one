package productdemo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ProductController {
    private Product model;
    public static ObservableList<Product> products =  FXCollections.observableArrayList();
    
    
    public ProductController(Product model) {
        
        this.model = Product.getProductInstance();
        
    }
    public void SetProductName(String productName) {
        this.model.setProductName(productName);
    }
    public String getProductName() {
        return this.model.getProductName();
    }
    public void setProductPrice(double productPrice) {
        this.model.setProductPrice(productPrice);
    }
    public double getProductPrice() {
        return this.model.getProductPrice();
    }
    public void setProductAmount(int productAmount) {
        this.model.setProductAmount(productAmount);
    }
    public int getProductAmount() {
        return this.model.getProductAmount();
    }
    public void setProductShipped(int productShipped) {
        this.model.setProductShipped(productShipped);
    }
    public int getProductShipped() {
        return this.model.getProductShipped();
    }
    public ObservableList<Product> getProduct() {
        return products;
    }
    public void addProduct(Product product) {
        products.add(product);
        
    }
    public ObservableList<Product> updateProductList() {
        return getProduct();
    }
    public void deleteProduct(int deleteRow) {
        products.remove(deleteRow);
        
        
    }
    public void buyProduct(int row, Product product) {
        products.add(product);
        
        products.remove(row);
    }
    public void login() {
        
    }
    public void fillData() {
        products.add(new Product("Lenove pc", 800, 3543, 0));
        products.add(new Product("Juice", 10, 23453, 8));
        products.add(new Product("T-shirt", 12, 2309, 0));
        products.add(new Product("Car", 1800, 345, 14));
        products.add(new Product("Pionao", 1000, 990, 3));
    }
}