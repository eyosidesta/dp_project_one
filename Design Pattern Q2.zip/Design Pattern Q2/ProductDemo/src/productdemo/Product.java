package productdemo;

public class Product {
    private String productName;
    private double productPrice;
    private int productAmount;
    private int productShipped;
    
    private static Product productInstance = new Product();
//    private  Product productInstanceWithParameter = new Product(productName, productPrice, productAmount, productShipped);
    private Product() {
        this.productName = "";
        this.productPrice = 0;
        this.productAmount = 0;
        this.productShipped = 0;
    }
    public static Product getProductInstance() {
        return productInstance;
    }
    
    Product(String productName,double productPrice, int productAmount, int productShipped) {
        this.productName = productName;
        this.productPrice = productPrice;
        this.productAmount = productAmount;
        this.productShipped = productShipped;
    }
//    public Product getProductWithParameter(String productName, double productPrice, int productAmount, int productShipped) {
//        return productInstanceWithParameter;
//    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    
    public String getProductName() {
        return this.productName;
    }
    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }
    public double getProductPrice() {
        return this.productPrice;
    }
    public void setProductAmount(int productAmount) {
        this.productAmount = productAmount;
    }
    public int getProductAmount() {
        return this.productAmount;
    }
    public void setProductShipped(int productShipped) {
        this.productShipped = productShipped;
    }
    public int getProductShipped() {
        return this.productShipped;
    }
    
}
